#code fully written by Troy for thesis purposes
import screen_cap

cap = screen_cap.screen_cap()
cap.get_png()
print("screenshot saved as screenshot.png")