log =  open("log.txt")
total = 0
count = 0
max = 0
maxcount = 0
min = 50
mincount = 50
valuelist = []

for line in log.readlines():
    words = line.split()
    if words[0] != "Saving":
        continue

    total += float(words[6])
    valuelist.append(float(words[6]))
    count +=1

    if float(words[6]) > max:
        max = float(words[6])
        maxcount = count
    
    if float(words[6]) < min:
        min = float(words[6])
        mincount = count

    if count == 260:
        break

avg = total/count
valuelist.sort()
median = valuelist[int(count/2)]

print("avg:", avg)
print("max:", max)
print("maxcount:", maxcount)
print("min:", min)
print("mincount:", mincount)
print("median:", median)

log.close()