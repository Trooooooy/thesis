#Almost all code by troy, only the class and function names are taken from Sethbling

import numpy as np
import ctypes
ctypes.windll.user32.SetProcessDPIAware()
import pygetwindow as gw
import mss
from skimage import transform

frameshape = [21, 18, 4]

def get_bizhawk_bbox():
    windows = gw.getWindowsWithTitle("SNES") #bizhawk window name changes after the loaded game
    for win in windows:
        
		#Return bounding box (left, top, width, height)
    	# return {                                          #these are for the entire top half of the screen, hardcoded for a small window size, should be about 256x112 (top half of original SNES res)
        #         "left": win.left+253,
        #         "top": win.top+85,
        #         "width": win.width + 100,
        #         "height": win.height // 2 -15
        #     	}
        return {                                            #these are for just a small area around (and above) the player kart, dynamically coded to hopefully work for more window sizes
                "left": win.left + (win.width // 3),        #size should be about 85x75, works best on windows display scaling of 100%
                "top": win.top +60 + ((win.height-93)//8),    #FRAME FOR croppedvisual.cfg AND doubleconvcropped.cfg
                "width": win.width // 3,
                "height": (win.height-93) // 2 -((win.height-93)//6)
            	}
        # return {                                            #these are for a smaller area in front of the player kart, dynamically coded to hopefully work for more window sizes
        #         "left": win.left + (win.width // 3),        #size should be about 85x37, works best on windows display scaling of 100%
        #         "top": win.top +60 + ((win.height-93)//8),  #FRAME FOR doubleconvcroppedRNN.cfg
        #         "width": win.width // 3,
        #         "height": (win.height-93) // 2 -((win.height-93)//3)
        #     	}


class screen_cap:
    def __init__(self):
        self.cap = get_bizhawk_bbox()
        if self.cap == None:
              print("Game window not found! Big sad")
		
    def get(self):
        screenshot = mss.mss()
        frame = screenshot.grab(self.cap)
        frame = np.array(frame)
        frame = transform.resize(frame, (21, 18), anti_aliasing= True)  
        # print("frame shape:", frame.shape) #test, gives the array size of the frame
        shape = frame.shape
        # frame = frame.reshape(shape[0]*shape[1]*shape[2]) #turns the frame into a 2D array (necessary for Tensorflow later), this line is only necessary if not using any conv layers
        # print(frame.shape) #test, gives the new array size 

        return frame
    
    def size(self):
        # return  [frameshape[0]*frameshape[1]*frameshape[2]]  #[CapBottom - CapTop, CapRight - CapLeft, ColorDepth]
        return frameshape

    def get_png(self): #save screen as png file to see if the window is properly grabbed and cropped
        screenshot = mss.mss()
        frame = screenshot.grab(self.cap)
        png = mss.tools.to_png(frame.rgb, frame.size, output= "screenshot.png") 
    
